![机械螺杆助力轨道](block:betterwithmods:booster)

当这个轨道被放置在已充能的 [木质变速箱](wooden_gearbox.md)上时，它会像被激活的充能铁轨那样对矿车进行加速。