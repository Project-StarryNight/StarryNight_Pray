![Hemp](item:betterwithmods:material@2)
![Hemp Seed](block:betterwithmods:hemp)

大麻是一种非常有用的纤维植物，其纤维可以制作[麻绳](../items/rope.md)或者[大麻布](../items/fabric.md)

而如果开启了“硬核种子” 那么大麻种子则只能通过用锄头锄地获得；如果没有开启则通过打高草丛获得

大麻必须要种在湿润的田地以及阳光照射才会生长，除了太阳光以外也能接受[发光灯](light.md)的光。
而[肥沃的田地](fertile_farmland.md)也能加速大麻的生长


大麻有两种生长阶段，最好的采集方式是只采集最顶上的那部分。就像甘蔗那样

![大麻的第一个生长阶段](betterwithmods:hemp-stage-1.png)
![大麻的第二个生长阶段](betterwithmods:hemp-stage-2.png)