ModernityExtra - Jappa texture by RuiXuqi
MCBBS:https://www.mcbbs.net/thread-1280646-1-1.html
MCMOD:https://bbs.mcmod.cn/thread-7760-1-1.html
Thank For
Enderized(Jappafied Modded owner)
Cr_L(Optifine helper)
DT_Fuel(Lots of textures)
Linecron Akrania(NuclearCraft texture)